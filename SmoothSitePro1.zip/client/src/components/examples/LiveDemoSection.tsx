import LiveDemoSection from '../LiveDemoSection';

export default function LiveDemoSectionExample() {
  return <LiveDemoSection />;
}
