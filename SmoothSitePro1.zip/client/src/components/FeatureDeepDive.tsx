import { Card } from "@/components/ui/card";
import { CheckCircle2, Sparkles } from "lucide-react";

export default function FeatureDeepDive() {
  const features = [
    {
      title: "Comprehensive Automation",
      tag: "Core Features",
      tagColor: "bg-primary/10 text-primary border-primary/20",
      description: "BonelzBot is the cheapest and only undetectable CoC bot on the market. From auto-farming to wall upgrades, every feature is designed for maximum efficiency.",
      benefits: [
        "Auto-Farm: Attacks only start after your loot targets are reached",
        "Auto-Wall-Upgrade: Spends Gold/Elixir on the cheapest walls automatically",
        "Human-Like Input: Ghost clicks, random offsets, and variable pause windows",
        "OCR-Driven: EasyOCR reads on-screen numbers with no hard-coded values",
        "Custom Hero Ability: User-selected time to use specified hero's ability",
        "Error Recovery: Keeps running even if issues occur"
      ],
      reverse: false
    },
    {
      title: "Unmatched Advantages",
      tag: "Why BonelzBot",
      tagColor: "bg-purple-500/10 text-purple-500 border-purple-500/20",
      description: "With over 700 sales across SellAuth and Night Village communities, BonelzBot has become the fastest-growing and most affordable bot on the market.",
      benefits: [
        "100% Undetectable: Works like a real player with advanced anti-detection",
        "Save Time: Forget boring farming and focus on strategy",
        "Fully Customizable: Adjust strategies to your playstyle",
        "Hands-Free: Play smarter, not harder with full automation",
        "Lifetime License: Pay once, use forever with constant updates",
        "Free & Constant Updates: Always up to date with game changes"
      ],
      reverse: true
    },
    {
      title: "Smart Loot Management",
      tag: "Advanced Config",
      tagColor: "bg-blue-500/10 text-blue-500 border-blue-500/20",
      description: "Set precise thresholds for Gold, Elixir, and Dark Elixir. The bot will only attack villages that meet your minimum requirements, ensuring every raid is profitable.",
      benefits: [
        "Gold Threshold: Minimum Gold required before committing to attack (e.g., 500k)",
        "Elixir Threshold: Control engagement based on Elixir availability (e.g., 450k)",
        "Dark Elixir Target: Prioritize high-value raids (e.g., 10k minimum)",
        "Customizable Limits: Fine-tune every aspect of your farming strategy",
        "Smart Scanning: Detects resources to attack only worthwhile villages",
        "Trophy Drop Control: Set limits to avoid legend league (e.g., 4950 max)"
      ],
      reverse: false
    }
  ];

  return (
    <section className="py-20 bg-background">
      <div className="max-w-7xl mx-auto px-6 space-y-20">
        {features.map((feature, index) => (
          <div
            key={index}
            className={`grid lg:grid-cols-2 gap-12 items-start ${feature.reverse ? 'lg:grid-flow-dense' : ''}`}
            data-testid={`feature-detail-${index}`}
          >
            <div className={feature.reverse ? 'lg:col-start-2' : ''}>
              <div className="sticky top-24">
                <div className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-full border text-sm font-medium mb-4 ${feature.tagColor}`}>
                  <Sparkles className="w-3.5 h-3.5" />
                  {feature.tag}
                </div>
                <h3 className="font-display font-bold text-3xl sm:text-4xl mb-4">
                  {feature.title}
                </h3>
                <p className="text-lg text-muted-foreground mb-6 leading-relaxed">
                  {feature.description}
                </p>
              </div>
            </div>
            <div className={feature.reverse ? 'lg:col-start-1 lg:row-start-1' : ''}>
              <Card className="p-6">
                <ul className="space-y-4">
                  {feature.benefits.map((benefit, idx) => {
                    const [title, desc] = benefit.split(':');
                    return (
                      <li key={idx} className="flex gap-3">
                        <CheckCircle2 className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                        <div className="flex-1">
                          <span className="font-semibold">{title}</span>
                          {desc && <span className="text-muted-foreground">: {desc}</span>}
                        </div>
                      </li>
                    );
                  })}
                </ul>
              </Card>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
