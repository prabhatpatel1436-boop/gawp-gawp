import { motion } from "framer-motion";
import { useEffect, useState, useRef } from "react";
import { usePrefersReducedMotion } from "@/hooks/use-prefers-reduced-motion";

export default function StatsSection() {
  const prefersReducedMotion = usePrefersReducedMotion();

  const stats = [
    { number: 700, suffix: "+", label: "Active Users" },
    { number: 100, suffix: "%", label: "Undetected" },
    { number: 4.9, suffix: "/5", label: "Rating" },
  ];

  if (prefersReducedMotion) {
    return (
      <section className="py-20 bg-card/50 border-y border-border relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-primary/5 via-transparent to-primary/5" />
        <div className="max-w-7xl mx-auto px-6 relative z-10">
          <div className="grid grid-cols-2 md:grid-cols-3 gap-8 md:gap-12">
            {stats.map((stat, index) => (
              <div
                key={index}
                className={`text-center ${index === 2 ? 'col-span-2 md:col-span-1' : ''}`}
                data-testid={`stat-${index}`}
              >
                <div className="font-display font-bold text-5xl sm:text-6xl lg:text-7xl bg-gradient-to-br from-primary via-purple-500 to-purple-600 bg-clip-text text-transparent mb-3">
                  {stat.number}{stat.suffix}
                </div>
                <div className="text-sm sm:text-base text-muted-foreground uppercase tracking-wider font-medium">
                  {stat.label}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    );
  }

  return (
    <section className="py-20 bg-card/50 border-y border-border relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-r from-primary/5 via-transparent to-primary/5" />
      <div className="max-w-7xl mx-auto px-6 relative z-10">
        <div className="grid grid-cols-2 md:grid-cols-3 gap-8 md:gap-12">
          {stats.map((stat, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, scale: 0.5 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{
                duration: 0.6,
                delay: index * 0.15,
                ease: [0.25, 0.1, 0.25, 1],
              }}
              className={`text-center ${index === 2 ? 'col-span-2 md:col-span-1' : ''}`}
              data-testid={`stat-${index}`}
            >
              <motion.div
                whileHover={{ scale: 1.1, rotate: [0, -5, 5, 0] }}
                transition={{ duration: 0.5 }}
                className="font-display font-bold text-5xl sm:text-6xl lg:text-7xl bg-gradient-to-br from-primary via-purple-500 to-purple-600 bg-clip-text text-transparent mb-3"
              >
                <CountUp end={stat.number} suffix={stat.suffix} />
              </motion.div>
              <div className="text-sm sm:text-base text-muted-foreground uppercase tracking-wider font-medium">
                {stat.label}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

function CountUp({ end, suffix }: { end: number; suffix: string }) {
  const [count, setCount] = useState(0);
  const [hasAnimated, setHasAnimated] = useState(false);
  const ref = useRef<HTMLSpanElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting && !hasAnimated) {
          setHasAnimated(true);
          const duration = 2000;
          const steps = 60;
          const increment = end / steps;
          let current = 0;

          const timer = setInterval(() => {
            current += increment;
            if (current >= end) {
              setCount(end);
              clearInterval(timer);
            } else {
              setCount(Math.floor(current * 10) / 10);
            }
          }, duration / steps);

          return () => clearInterval(timer);
        }
      },
      { threshold: 0.5 }
    );

    if (ref.current) {
      observer.observe(ref.current);
    }

    return () => observer.disconnect();
  }, [end, hasAnimated]);

  return (
    <span ref={ref}>
      {count === end ? count : Math.floor(count)}
      {suffix}
    </span>
  );
}
