import { Card } from "@/components/ui/card";
import { Quote } from "lucide-react";

export default function MotivationalSection() {
  const quotes = [
    {
      text: "Winners focus on winning. Losers focus on winners.",
      subtext: "While they grind manually, you farm automatically."
    },
    {
      text: "The grind never stops, but you can.",
      subtext: "Let BonelzBot work 24/7 while you dominate strategy."
    },
    {
      text: "Success is automatic when you automate success.",
      subtext: "700+ players already upgraded their game. Join them."
    },
    {
      text: "Time is the only currency you can't farm back.",
      subtext: "Stop wasting it. Start automating it."
    }
  ];

  return (
    <section className="relative py-20 bg-gradient-to-br from-primary/5 via-purple-500/5 to-blue-500/5 overflow-hidden">
      <div className="relative z-10 max-w-7xl mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="font-display font-bold text-4xl sm:text-5xl mb-4 text-foreground">
            Play Smarter, Not Harder
          </h2>
          <p className="text-lg text-foreground/80 max-w-2xl mx-auto">
            The grind mindset meets automation intelligence
          </p>
        </div>

        <div className="grid sm:grid-cols-2 gap-6 max-w-5xl mx-auto">
          {quotes.map((quote, index) => (
            <Card 
              key={index} 
              className="p-6 hover-elevate transition-all bg-gradient-to-br from-card to-card/50"
              data-testid={`quote-card-${index}`}
            >
              <div className="flex gap-4">
                <div className="flex-shrink-0">
                  <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                    <Quote className="w-5 h-5 text-primary" />
                  </div>
                </div>
                <div className="flex-1">
                  <p className="font-semibold text-lg mb-2 leading-relaxed">
                    "{quote.text}"
                  </p>
                  <p className="text-sm text-muted-foreground italic">
                    {quote.subtext}
                  </p>
                </div>
              </div>
            </Card>
          ))}
        </div>

        <div className="mt-12 text-center">
          <div className="inline-block p-6 rounded-lg bg-gradient-to-r from-primary/10 via-purple-500/10 to-blue-500/10 border border-primary/20">
            <p className="font-display font-bold text-2xl sm:text-3xl mb-2 text-primary">
              "They'll ask how you maxed out so fast. You don't have to tell them."
            </p>
            <p className="text-sm text-muted-foreground">
              — Every BonelzBot user
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
