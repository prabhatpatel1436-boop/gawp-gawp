import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { PlayCircle, BarChart3, Hammer, Settings, CheckCircle2 } from "lucide-react";

export default function LiveDemoSection() {
  const features = [
    {
      icon: PlayCircle,
      title: "Control & Log",
      badge: "Real-Time",
      highlights: [
        "Start Bot: Launch farming with live status",
        "Stop Bot: Halt operations instantly",
        "Save Config: Write settings to disk",
        "Live Log Window: Scrolls events in real-time"
      ]
    },
    {
      icon: BarChart3,
      title: "Raid & Loot Stats",
      badge: "Analytics",
      highlights: [
        "Webhook URL: Display live bot stats remotely",
        "Total Resources: Track Gold, Elixir, Dark Elixir",
        "Average Resources/hr: Calculate farming efficiency",
        "Raid Details: Wins, losses, total raids, uptime"
      ]
    },
    {
      icon: Hammer,
      title: "Wall Upgrade",
      badge: "Automation",
      highlights: [
        "Enable Wall Upgrade: Toggle auto-wall routine",
        "Wall Cost: Set Gold/Elixir spending threshold",
        "Number of Walls: Upgrade count before terminating",
        "Discord Support: Save logs with one click"
      ]
    },
    {
      icon: Settings,
      title: "Basic Config",
      badge: "Customization",
      highlights: [
        "Slots (1-11): Choose troop slots to use",
        "Counts per Slot: Troops to drop per slot",
        "Spell Slots: Specify spell slot numbers",
        "Drop Trophies: Prevent legend league"
      ]
    }
  ];

  return (
    <section className="py-20 bg-card/30">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="font-display font-bold text-4xl sm:text-5xl mb-4">
            Complete Bot Control
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            User-friendly GUI with hotkeys, live logs, and comprehensive configuration
          </p>
        </div>

        <div className="grid sm:grid-cols-2 gap-6">
          {features.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <Card key={index} className="hover-elevate transition-all" data-testid={`control-card-${index}`}>
                <CardHeader className="pb-4">
                  <div className="flex items-start justify-between gap-4 mb-3">
                    <div className="w-12 h-12 rounded-md bg-primary/10 flex items-center justify-center flex-shrink-0">
                      <Icon className="w-6 h-6 text-primary" />
                    </div>
                    <Badge variant="secondary" className="text-xs">{feature.badge}</Badge>
                  </div>
                  <h3 className="font-semibold text-xl">{feature.title}</h3>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2.5">
                    {feature.highlights.map((highlight, idx) => (
                      <li key={idx} className="flex items-start gap-2.5 text-sm">
                        <CheckCircle2 className="w-4 h-4 text-primary flex-shrink-0 mt-0.5" />
                        <span className="leading-relaxed">{highlight}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </section>
  );
}
