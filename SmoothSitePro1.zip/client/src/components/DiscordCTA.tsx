import { Button } from "@/components/ui/button";
import { SiDiscord } from "react-icons/si";
import { Shield, Zap, Users } from "lucide-react";

export default function DiscordCTA() {
  return (
    <section className="py-20 bg-gradient-to-br from-primary/10 via-purple-500/10 to-primary/10">
      <div className="max-w-4xl mx-auto px-6 text-center">
        <div className="mb-8">
          <div className="w-20 h-20 mx-auto mb-6 rounded-full bg-primary/20 flex items-center justify-center">
            <SiDiscord className="w-10 h-10 text-primary" />
          </div>
          <h2 className="font-display font-bold text-4xl sm:text-5xl mb-4">
            Ready to Dominate Clash of Clans?
          </h2>
          <p className="text-lg sm:text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            Join 700+ players in our Discord community and start automating your village today
          </p>
        </div>

        <Button asChild size="lg" className="gap-2 text-lg px-8 py-6 h-auto" data-testid="button-join-discord-cta">
          <a href="https://discord.gg/FE7Ctv7dsE" target="_blank" rel="noopener noreferrer">
            <SiDiscord className="w-5 h-5" />
            Join BonelzBot Discord
          </a>
        </Button>

        <div className="flex flex-wrap gap-8 justify-center mt-12 text-sm">
          <div className="flex items-center gap-2">
            <Zap className="w-4 h-4 text-primary" />
            <span className="text-muted-foreground">Instant Support</span>
          </div>
          <div className="flex items-center gap-2">
            <Shield className="w-4 h-4 text-primary" />
            <span className="text-muted-foreground">Exclusive Updates</span>
          </div>
          <div className="flex items-center gap-2">
            <Users className="w-4 h-4 text-primary" />
            <span className="text-muted-foreground">Active Community</span>
          </div>
        </div>
      </div>
    </section>
  );
}
