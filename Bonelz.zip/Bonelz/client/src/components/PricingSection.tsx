import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { CheckCircle2 } from "lucide-react";
import { SiDiscord } from "react-icons/si";
import { useState } from "react";

export default function PricingSection() {
  const [currency, setCurrency] = useState<'EUR' | 'USD'>('EUR');

  const plans = [
    {
      name: "Home Village Bot",
      badge: "Most Popular",
      prices: { EUR: "7.99 - 9.99", USD: "9.59 - 11.99" },
      description: "Complete automation for Home Village with lifetime access",
      features: [
        "Auto-Farm with smart loot scanning",
        "Auto-Wall-Upgrade automation",
        "OCR-driven adaptive attacks",
        "Human-like anti-detection system",
        "Custom hero ability timing",
        "Trophy drop control",
        "24/7 Discord support",
        "Lifetime license + free updates"
      ],
      cta: "Get Home Village Bot",
      popular: true
    },
    {
      name: "Night Village Bot",
      badge: "Same Features",
      prices: { EUR: "7.99 - 9.99", USD: "9.59 - 11.99" },
      description: "Complete automation for Night Village with lifetime access",
      features: [
        "Auto-Farm with smart loot scanning",
        "Auto-Wall-Upgrade automation",
        "OCR-driven adaptive attacks",
        "Human-like anti-detection system",
        "Custom hero ability timing",
        "Trophy drop control",
        "24/7 Discord support",
        "Lifetime license + free updates"
      ],
      cta: "Get Night Village Bot",
      popular: false
    }
  ];

  return (
    <section id="pricing" className="py-20 bg-card/30">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="font-display font-bold text-4xl sm:text-5xl mb-4">
            Choose Your Plan
          </h2>
          <p className="text-lg text-foreground/75 mb-8 max-w-2xl mx-auto">
            Affordable pricing with lifetime access and continuous updates
          </p>

          <div className="inline-flex items-center gap-2 p-1 bg-muted rounded-md" data-testid="currency-toggle">
            <button
              onClick={() => setCurrency('EUR')}
              className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                currency === 'EUR' ? 'bg-background shadow-sm' : 'text-muted-foreground hover:text-foreground'
              }`}
              data-testid="button-currency-eur"
            >
              EUR (€)
            </button>
            <button
              onClick={() => setCurrency('USD')}
              className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                currency === 'USD' ? 'bg-background shadow-sm' : 'text-muted-foreground hover:text-foreground'
              }`}
              data-testid="button-currency-usd"
            >
              USD ($)
            </button>
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto">
          {plans.map((plan, index) => (
            <Card
              key={index}
              className={`relative hover-elevate transition-all duration-300 ${
                plan.popular ? 'border-primary shadow-lg' : ''
              }`}
              data-testid={`pricing-card-${index}`}
            >
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 -translate-x-1/2">
                  <Badge className="bg-primary text-primary-foreground shadow-lg" data-testid="badge-popular">
                    {plan.badge}
                  </Badge>
                </div>
              )}
              {!plan.popular && (
                <div className="absolute -top-4 left-1/2 -translate-x-1/2">
                  <Badge variant="secondary" data-testid="badge-premium">
                    {plan.badge}
                  </Badge>
                </div>
              )}
              
              <CardHeader className="text-center pb-8 pt-8">
                <h3 className="font-display font-bold text-2xl mb-2">{plan.name}</h3>
                <div className="mb-2">
                  <span className="text-4xl font-bold">
                    {currency === 'EUR' ? '€' : '$'}{plan.prices[currency]}
                  </span>
                  {plan.prices[currency] !== 'Custom' && (
                    <span className="text-sm text-foreground/60 ml-2">/ lifetime</span>
                  )}
                </div>
                <p className="text-sm text-foreground/70">{plan.description}</p>
              </CardHeader>

              <CardContent className="pb-8">
                <ul className="space-y-3">
                  {plan.features.map((feature, idx) => (
                    <li key={idx} className="flex gap-3">
                      <CheckCircle2 className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                      <span className="text-sm">{feature}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>

              <CardFooter>
                <Button
                  asChild
                  className="w-full gap-2"
                  variant={plan.popular ? "default" : "outline"}
                  size="lg"
                  data-testid={`button-${plan.cta.toLowerCase().replace(/\s+/g, '-')}`}
                >
                  <a href="https://discord.gg/FE7Ctv7dsE" target="_blank" rel="noopener noreferrer">
                    <SiDiscord className="w-4 h-4" />
                    {plan.cta}
                  </a>
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>

        <p className="text-center text-sm text-foreground/70 mt-8">
          Secure payment via Discord • Instant access after purchase
        </p>
      </div>
    </section>
  );
}
