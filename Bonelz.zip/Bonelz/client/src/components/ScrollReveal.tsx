import { motion } from "framer-motion";
import { ReactNode } from "react";
import { useScrollAnimation } from "@/hooks/use-scroll-animation";
import { usePrefersReducedMotion } from "@/hooks/use-prefers-reduced-motion";

interface ScrollRevealProps {
  children: ReactNode;
  direction?: "up" | "down" | "left" | "right" | "fade";
  delay?: number;
  duration?: number;
  className?: string;
}

export default function ScrollReveal({
  children,
  direction = "up",
  delay = 0,
  duration = 0.6,
  className = "",
}: ScrollRevealProps) {
  const { ref, isVisible } = useScrollAnimation(0.1);
  const prefersReducedMotion = false;

  const variants = {
    up: { y: 50, opacity: 0 },
    down: { y: -50, opacity: 0 },
    left: { x: 50, opacity: 0 },
    right: { x: -50, opacity: 0 },
    fade: { opacity: 0 },
  };

  if (prefersReducedMotion) {
    return <div className={className}>{children}</div>;
  }

  return (
    <motion.div
      ref={ref}
      initial={variants[direction]}
      animate={
        isVisible
          ? { x: 0, y: 0, opacity: 1 }
          : variants[direction]
      }
      transition={{
        duration,
        delay,
        ease: [0.45, 0, 0.55, 1],
      }}
      style={{
        willChange: isVisible ? 'auto' : 'transform, opacity',
        transform: 'translate3d(0, 0, 0)',
        visibility: 'visible',
        position: 'relative',
        zIndex: 1,
      }}
      className={className}
    >
      {children}
    </motion.div>
  );
}
