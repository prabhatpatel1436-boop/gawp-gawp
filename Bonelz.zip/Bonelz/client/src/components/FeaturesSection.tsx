import { Card, CardContent } from "@/components/ui/card";
import { Target, Swords, Hammer, ScanEye, Shuffle, RefreshCw, Monitor, Users } from "lucide-react";
import { motion } from "framer-motion";
import { usePrefersReducedMotion } from "@/hooks/use-prefers-reduced-motion";

export default function FeaturesSection() {
  const prefersReducedMotion = usePrefersReducedMotion();

  const features = [
    {
      icon: Swords,
      title: "Auto Attack",
      description: "Automatically starts night battles and finds opponents for maximum farming efficiency.",
      gradient: "from-red-500/10 to-orange-500/10",
      iconColor: "text-red-500"
    },
    {
      icon: Target,
      title: "Army Flexibility",
      description: "Attack with any army composition. Customize your strategies to match your playstyle.",
      gradient: "from-blue-500/10 to-cyan-500/10",
      iconColor: "text-blue-500"
    },
    {
      icon: Hammer,
      title: "Wall Upgrade",
      description: "Instantly upgrades night village walls when storage is full. Smart resource management.",
      gradient: "from-yellow-500/10 to-amber-500/10",
      iconColor: "text-yellow-600"
    },
    {
      icon: ScanEye,
      title: "Smart Scanning",
      description: "Detects resources to attack only villages with enough loot. No wasted attacks.",
      gradient: "from-purple-500/10 to-pink-500/10",
      iconColor: "text-purple-500"
    },
    {
      icon: Shuffle,
      title: "Random Actions",
      description: "Mimics human clicks with natural pauses and random offsets for maximum safety.",
      gradient: "from-green-500/10 to-emerald-500/10",
      iconColor: "text-green-500"
    },
    {
      icon: RefreshCw,
      title: "Error Recovery",
      description: "Keeps running even if issues occur. Automatic problem detection and resolution.",
      gradient: "from-indigo-500/10 to-violet-500/10",
      iconColor: "text-indigo-500"
    },
    {
      icon: Monitor,
      title: "Advanced GUI",
      description: "Easy-to-use interface with info buttons for guidance. Live logs and hotkeys included.",
      gradient: "from-teal-500/10 to-cyan-500/10",
      iconColor: "text-teal-500"
    },
    {
      icon: Users,
      title: "Multi-Account",
      description: "Manage multiple villages simultaneously with individual settings for each account.",
      gradient: "from-rose-500/10 to-pink-500/10",
      iconColor: "text-rose-500"
    },
  ];

  if (prefersReducedMotion) {
    return (
      <section id="features" className="py-24 bg-background relative">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="font-display font-bold text-4xl sm:text-5xl lg:text-6xl mb-6 bg-gradient-to-br from-foreground to-foreground/70 bg-clip-text text-transparent">
              Powerful Automation Features
            </h2>
            <p className="text-lg sm:text-xl text-foreground/75 max-w-2xl mx-auto leading-relaxed">
              Everything you need to dominate Clash of Clans while you sleep
            </p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <Card
                  key={index}
                  className={`h-full transition-all duration-300 bg-gradient-to-br ${feature.gradient} backdrop-blur-sm border-primary/20`}
                  data-testid={`feature-card-${index}`}
                >
                  <CardContent className="p-6">
                    <div className={`w-14 h-14 rounded-xl bg-gradient-to-br from-background to-card flex items-center justify-center mb-4 shadow-lg`}>
                      <Icon className={`w-7 h-7 ${feature.iconColor}`} />
                    </div>
                    <h3 className="font-semibold text-xl mb-3">{feature.title}</h3>
                    <p className="text-sm text-foreground/70 leading-relaxed">
                      {feature.description}
                    </p>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </section>
    );
  }

  return (
    <section id="features" className="py-24 bg-background relative">
      <div className="max-w-7xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="font-display font-bold text-4xl sm:text-5xl lg:text-6xl mb-6 bg-gradient-to-br from-foreground to-foreground/70 bg-clip-text text-transparent">
            Powerful Automation Features
          </h2>
          <p className="text-lg sm:text-xl text-foreground/75 max-w-2xl mx-auto leading-relaxed">
            Everything you need to dominate Clash of Clans while you sleep
          </p>
        </motion.div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{
                  duration: 0.5,
                  delay: index * 0.1,
                  ease: [0.25, 0.1, 0.25, 1],
                }}
              >
                <motion.div
                  whileHover={{
                    y: -8,
                    transition: { duration: 0.3, ease: "easeOut" },
                  }}
                >
                  <Card
                    className={`h-full transition-all duration-300 hover:shadow-xl hover:shadow-primary/10 bg-gradient-to-br ${feature.gradient} backdrop-blur-sm border-primary/20 hover:border-primary/40`}
                    data-testid={`feature-card-${index}`}
                  >
                    <CardContent className="p-6">
                      <motion.div
                        whileHover={{ rotate: [0, -10, 10, 0], scale: 1.1 }}
                        transition={{ duration: 0.5 }}
                        className={`w-14 h-14 rounded-xl bg-gradient-to-br from-background to-card flex items-center justify-center mb-4 shadow-lg`}
                      >
                        <Icon className={`w-7 h-7 ${feature.iconColor}`} />
                      </motion.div>
                      <h3 className="font-semibold text-xl mb-3">{feature.title}</h3>
                      <p className="text-sm text-foreground/70 leading-relaxed">
                        {feature.description}
                      </p>
                    </CardContent>
                  </Card>
                </motion.div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
