import { motion } from "framer-motion";
import { usePrefersReducedMotion } from "@/hooks/use-prefers-reduced-motion";

export default function AnimatedBackground() {
  const prefersReducedMotion = false;

  const orbs = [
    {
      src: "/orbs/Blue_purple_glowing_orb_d5f4ee52.png",
      className: "absolute -top-10 -left-10 w-[500px] h-[500px] blur-[120px] opacity-20",
      animation: {
        duration: 25,
        delay: 0,
        x: [0, 60, -30, 0],
        y: [0, -70, -40, 0],
        scale: [1, 1.2, 0.9, 1],
        rotate: [0, 90, 180, 360]
      }
    },
    {
      src: "/orbs/Indigo_violet_glowing_orb_4b573675.png",
      className: "absolute -bottom-10 -right-10 w-[550px] h-[550px] blur-[130px] opacity-15",
      animation: {
        duration: 30,
        delay: 3,
        x: [0, -50, 40, 0],
        y: [0, 60, 30, 0],
        scale: [1, 0.85, 1.15, 1],
        rotate: [0, -90, -180, -360]
      }
    },
    {
      src: "/orbs/Purple_pink_glowing_orb_fee452b8.png",
      className: "absolute top-1/3 left-1/4 w-[400px] h-[400px] blur-[110px] opacity-10",
      animation: {
        duration: 28,
        delay: 6,
        x: [0, 45, -25, 20, 0],
        y: [0, -35, -50, -20, 0],
        scale: [1, 1.1, 0.95, 1.05, 1],
        rotate: [0, 120, 240, 300, 360]
      }
    },
    {
      src: "/orbs/Cyan_blue_glowing_orb_dd7f15ae.png",
      className: "absolute top-1/2 right-1/3 w-[450px] h-[450px] blur-[125px] opacity-15",
      animation: {
        duration: 32,
        delay: 9,
        x: [0, -55, 35, -15, 0],
        y: [0, 50, 25, 45, 0],
        scale: [1, 0.9, 1.2, 0.95, 1],
        rotate: [0, -120, -240, -300, -360]
      }
    },
    {
      src: "/orbs/Blue_purple_glowing_orb_d5f4ee52.png",
      className: "absolute bottom-1/4 left-1/3 w-[380px] h-[380px] blur-[105px] opacity-10",
      animation: {
        duration: 26,
        delay: 4,
        x: [0, 38, -20, 0],
        y: [0, -45, -25, 0],
        scale: [1, 1.15, 0.88, 1],
        rotate: [0, 60, 120, 180]
      }
    }
  ];

  if (prefersReducedMotion) {
    return (
      <div className="fixed inset-0 overflow-hidden pointer-events-none z-0">
        <div className="absolute inset-0 bg-gradient-to-br from-background via-background to-background/80" />
        {orbs.map((orb, index) => (
          <img
            key={index}
            src={orb.src}
            alt=""
            className={orb.className}
            loading="lazy"
          />
        ))}
      </div>
    );
  }

  return (
    <div className="fixed inset-0 overflow-hidden pointer-events-none -z-10">
      <div className="absolute inset-0 bg-gradient-to-br from-background via-background to-background/80" />
      {orbs.map((orb, index) => (
        <motion.img
          key={index}
          src={orb.src}
          alt=""
          className={orb.className}
          loading="lazy"
          style={{
            willChange: 'transform',
            transform: 'translate3d(0, 0, 0)',
          }}
          animate={{
            x: orb.animation.x,
            y: orb.animation.y,
            scale: orb.animation.scale,
            rotate: orb.animation.rotate,
          }}
          transition={{
            duration: orb.animation.duration,
            repeat: Infinity,
            ease: [0.45, 0, 0.55, 1],
            delay: orb.animation.delay,
            repeatType: "loop",
          }}
        />
      ))}
    </div>
  );
}