import { SiDiscord } from "react-icons/si";
import { Shield, Clock, Zap } from "lucide-react";

export default function Footer() {
  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <footer className="bg-card border-t border-border">
      <div className="max-w-7xl mx-auto px-6 py-12">
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8 mb-8">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 rounded-md bg-gradient-to-br from-primary to-purple-600 flex items-center justify-center">
                <span className="text-white font-bold text-lg">B</span>
              </div>
              <span className="font-display font-bold text-xl">BonelzBot</span>
            </div>
            <p className="text-sm text-foreground/70 leading-relaxed">
              The most advanced and affordable Clash of Clans automation bot trusted by 700+ players worldwide.
            </p>
          </div>

          <div>
            <h4 className="font-semibold mb-4">Quick Links</h4>
            <ul className="space-y-2 text-sm">
              <li>
                <button
                  onClick={() => scrollToSection('features')}
                  className="text-foreground/70 hover:text-foreground transition-colors"
                  data-testid="footer-link-features"
                >
                  Features
                </button>
              </li>
              <li>
                <button
                  onClick={() => scrollToSection('pricing')}
                  className="text-foreground/70 hover:text-foreground transition-colors"
                  data-testid="footer-link-pricing"
                >
                  Pricing
                </button>
              </li>
              <li>
                <button
                  onClick={() => scrollToSection('faq')}
                  className="text-foreground/70 hover:text-foreground transition-colors"
                  data-testid="footer-link-faq"
                >
                  FAQ
                </button>
              </li>
              <li>
                <a
                  href="https://discord.gg/FE7Ctv7dsE"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-foreground/70 hover:text-foreground transition-colors flex items-center gap-2"
                  data-testid="footer-link-discord"
                >
                  <SiDiscord className="w-4 h-4" />
                  Discord
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="font-semibold mb-4">Support</h4>
            <ul className="space-y-2 text-sm">
              <li>
                <a
                  href="https://discord.gg/FE7Ctv7dsE"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-foreground/70 hover:text-foreground transition-colors"
                  data-testid="footer-link-contact"
                >
                  Contact Us
                </a>
              </li>
              <li>
                <span className="text-foreground/70">Documentation</span>
              </li>
              <li>
                <span className="text-foreground/70">Community</span>
              </li>
              <li>
                <span className="text-foreground/70">Terms of Service</span>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="font-semibold mb-4">Trust Badges</h4>
            <div className="space-y-3 text-sm">
              <div className="flex items-center gap-2 text-foreground/75">
                <Shield className="w-4 h-4 text-primary" />
                <span>100% Undetectable</span>
              </div>
              <div className="flex items-center gap-2 text-foreground/75">
                <Zap className="w-4 h-4 text-primary" />
                <span>Instant Access</span>
              </div>
              <div className="flex items-center gap-2 text-foreground/75">
                <Clock className="w-4 h-4 text-primary" />
                <span>24/7 Support</span>
              </div>
            </div>
          </div>
        </div>

        <div className="pt-8 border-t border-border text-center text-sm text-foreground/65">
          <p>© 2024 BonelzBot. All rights reserved.</p>
          <p className="mt-2">
            Premium Clash of Clans automation • Undetectable • Secure • Affordable
          </p>
        </div>
      </div>
    </footer>
  );
}
